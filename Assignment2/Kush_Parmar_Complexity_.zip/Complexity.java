//Kush Parmar
//I pledge my honor that I have abided by the stevens honor system-Kush Parmar
public class Complexity {
	//Question 1 O(n^2) this function calls each for loop for every iteration of that is less than n
	public static void method1(int n) {
		int counter=1;
		for(int i=0; i<n; i++) {
			for(int k=0; k<n;k++) {
				System.out.println("Operation "+counter );
				counter ++;
			}
		}
	}
	
	//Question 2 O(n^3) this function calls each for loop for every iteration of i that is less that n
	public static void method2(int n) {
		int counter=1;
		for(int i=0; i<n; i++) {
			for(int k=0; k<n;k++) {
				for(int j=0; j<n;j++) {
					System.out.println("Operation "+counter );
					counter ++;
				}
			}
		}
	}
	
	//Question 3 O(log(n)) this function would run the log base 2 of n as integers.
	public static void method3(int n) {
		int counter=1;
		for(int i=1; i<n; i*=2) {
			System.out.println("Operation "+counter );
			counter ++;
		}
	}
	/* Question 4 
	 * Iteration | start | end
	 * 1         |   0   |  31
	 * 2         |  16   |  31
	 * 3         |  24   |  31
	 * 4         |  28   |  31
	 * 5         |  30   |  31
	 * 6         |  31   |  31
	 * ---------------------------------------
	 * 
	 * Iteration | start | end
	 * 1         |   0   |  31
	 * 2         |  32   |  63
	 * 3         |  48   |  63
	 * 4         |  56   |  63
	 * 5         |  60   |  63
	 * 6         |  62   |  63
	 * 7         |  63   |  63 
	 * ---------------------------------------
	 * 
	 * Question 5 The answer would be O(log2(end))+1 . I came to this answer after plugging numbers
	 * into a calculator.
	 * 
	 * Question 6 log2(n) by graphing the output the graph forms a log function.
	 */
	
	// Question 7 O(n log(n)) This function would run log(n) for each iteration of n
	public static void method4(int n) {
		int counter=1;
		for(int i=0;i<n; i++) {
			for(int k=1; k<n; k*=2) {
				System.out.println("Operation "+counter );
				counter ++;
			}
		}
	}
	
	//Question 8 O(log log(n)) The way i wrote this program- where it would run the log of n , it would 
	// take that number and run log(n) that many times

    public static void method5(int n) {
    	int counter=1;
    	for(int i=1; i<n; i*=2) {
			counter++;    
		}
    	int c=counter;
    	counter=1;
    	for(int b=1; b<c ;b*=2) {
    		System.out.println("Operation " + counter);
			counter++;
    	}

    }
	// Extra credit time complexity O(2^n) the fibonacci sequence is a recursive function that would add the 
    // previous 2 functions. which is 2^n
    public static int method6(int n) {
    	if(n<=1)
    		return n ;
    	else
    		return method6(n-1)+method6(n-2);
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
